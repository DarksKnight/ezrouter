package com.haowanyou.plugin

import com.haowanyou.router.plugin.RouterPlugin
import org.gradle.api.Project
import org.gradle.api.ProjectConfigurationException
import org.gradle.testfixtures.ProjectBuilder
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExpectedException

class GRouterPluginTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none()

    @Before
    void setUp() {
    }

    @Test(expected = ProjectConfigurationException.class)
    void testWithoutAndroidPlugin() {
        Project project = ProjectBuilder.builder().build()
        configBuildScript(project, 'com.android.tools.build:gradle:3.0.1')
        new RouterPlugin().apply(project)
    }

    @Test
    void testWithAndroidPlugin() {
        Project project = ProjectBuilder.builder().build();
        configBuildScript(project, 'com.android.tools.build:gradle:3.0.1')
        project.apply plugin: 'com.android.application'
        new RouterPlugin().apply(project)
    }


    @Test
    void testVariantsAndBuildTypes() {
        Project project = createProject()
        project.evaluate()
        def variants = project.android.applicationVariants
        def variantNames = variants.collect { it.name }.join(' ')
        Assert.assertEquals(variants.size(), 3)
        Assert.assertTrue(variantNames.contains('beta'))

        def variantBeta = variants.find { it.buildType.name == 'beta' }
        Assert.assertEquals(variantBeta.buildType.name, 'beta')
    }

    private Project createProject() {
        Project project = ProjectBuilder.builder().withName('plugin-test').build()
        configBuildScript(project, 'com.android.tools.build:gradle:3.0.1')
        project.apply plugin: 'com.android.application';
        project.apply plugin: 'packer'
        project.android {
            compileSdkVersion 21
            buildToolsVersion "21.1.1"

            defaultConfig {
                minSdkVersion 14
                targetSdkVersion 21
                versionCode 1
                versionName "1.0.0"
                applicationId 'com.mcxiaoke.packer.test'
            }

            signingConfigs {
                release {
                    storeFile project.file("android.keystore")
                    storePassword "android"
                    keyAlias "android"
                    keyPassword "android"
                }

            }
        }
        return project
    }

    static void configBuildScript(Project project, String androidVersion) {
        project.buildscript {
            repositories {
                maven { url "/tmp/repo/" }
                mavenCentral()
            }
            dependencies {
                classpath androidVersion
            }
        }
    }

}
