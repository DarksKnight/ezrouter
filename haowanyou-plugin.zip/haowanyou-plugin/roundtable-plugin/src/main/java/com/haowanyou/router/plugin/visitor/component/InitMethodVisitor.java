package com.haowanyou.router.plugin.visitor.component;

import com.google.common.collect.Maps;

import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.util.List;
import java.util.Map;

/**
 * 组件初始化处理
 *
 * @author sunhaoyang
 */
public class InitMethodVisitor extends MethodVisitor {

    private Map<String, List<String>> mapComponent = Maps.newHashMap();
    private Map<String, List<String>> mapActivity = Maps.newHashMap();

    public InitMethodVisitor(int api, MethodVisitor mv) {
        super(api, mv);
    }

    public InitMethodVisitor(int api, MethodVisitor mv, Map<String, List<String>> mapComponent, Map<String, List<String>> mapActivity) {
        this(api, mv);
        this.mapComponent = mapComponent;
        this.mapActivity = mapActivity;
    }

    @Override
    public void visitInsn(int opcode) {
        //将初始化方法插入到ServiceLoader.class中
        Map<String, Map<String, List<String>>> mapInfo = Maps.newHashMap();
        mapInfo.put("component", mapComponent);
        mapInfo.put("page", mapActivity);
        mapInfo.forEach((mapInfoKey, mapInfoValue) -> {
            mapInfoValue.forEach((key, value) -> {
                String className = key.substring(key.lastIndexOf(".") + 1, key.length());
                String suffix = "";
                switch (mapInfoKey) {
                    case "component":
                        suffix = "Mediator";
                        break;
                    case "page":
                        suffix = "Page";
                        break;
                    default:
                        break;
                }
                mv.visitMethodInsn(Opcodes.INVOKESTATIC,
                        "com/haowanyou/router/extra/gen/" + mapInfoKey + "/" + className + suffix,
                        "init",
                        "()V",
                        false);
            });
        });
        super.visitInsn(opcode);
    }
}
