package com.haowanyou.router.plugin.visitor.component;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

import java.util.Collections;
import java.util.List;
import java.util.Map;


import static org.objectweb.asm.Opcodes.ALOAD;
import static org.objectweb.asm.Opcodes.CHECKCAST;
import static org.objectweb.asm.Opcodes.IFEQ;

/**
 * 处理自定义事件类
 *
 * @author sunhaoyang
 */
public class EventHandlerMethodVisitor extends MethodVisitor {

    private Map<String, List<String>> mapComponent = Maps.newHashMap();

    public EventHandlerMethodVisitor(int i, MethodVisitor methodVisitor) {
        super(i, methodVisitor);
    }

    public EventHandlerMethodVisitor(int api, MethodVisitor mv, Map<String, List<String>> mapComponent) {
        this(api, mv);
        this.mapComponent = mapComponent;
    }

    @Override
    public void visitInsn(int opcode) {
        List<EventInfo> listAllInfo = Lists.newArrayList();
        //对事件优先级进行排序
        //优先级越高越先调用
        for (String key : mapComponent.keySet()) {
            String name = key.substring(key.lastIndexOf(".") + 1, key.length());
            List<String> listInfo = mapComponent.get(key);
            for (String info : listInfo) {
                int priority = Integer.parseInt(Splitter.on(";").splitToList(info).get(3));
                listAllInfo.add(new EventInfo(name, info, priority));
            }
        }
        Collections.sort(listAllInfo, (s1, s2) -> s2.getPriority() - s1.getPriority());
        //将自定义事件插入到ServiceLoader.class中
        for (EventInfo eventInfo : listAllInfo) {
            System.out.println("info : " + eventInfo.getInfo());
            List<String> listEvent = Splitter.on(";").splitToList(eventInfo.getInfo());
            String event = listEvent.get(0);
            String paramsType = listEvent.get(1);
            String returnType = listEvent.get(2);
            mv.visitVarInsn(ALOAD, 0);
            mv.visitLdcInsn(event);
            mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL,
                    "java/lang/String",
                    "equals",
                    "(Ljava/lang/Object;)Z",
                    false);
            Label endLabel = new Label();
            mv.visitJumpInsn(IFEQ, endLabel);
            String desc = "()";
            String returnSign = "V";
            if (!paramsType.equals("null")) {
                mv.visitVarInsn(ALOAD, 1);
                mv.visitTypeInsn(CHECKCAST, paramsType.replaceAll("\\.", "/"));
                if (returnType.equals("java.lang.String")) {
                    returnSign = "Ljava/lang/String;";
                }
                desc = "(L" + paramsType.replaceAll("\\.", "/") + ";)" + returnSign;
            } else {
                if (returnType.equals("java.lang.String")) {
                    returnSign = "Ljava/lang/String;";
                }
                desc += returnSign;
            }
            mv.visitMethodInsn(Opcodes.INVOKESTATIC,
                    "com/haowanyou/router/extra/gen/component/" + eventInfo.getClassName() + "Mediator",
                    "event_" + event,
                    desc,
                    false);
            if (!returnType.equals("void")) {
                mv.visitInsn(Opcodes.ARETURN);
            }
            mv.visitLabel(endLabel);
        }
        super.visitInsn(opcode);
    }

    class EventInfo {
        private String className;
        private String info;
        private int priority;

        public EventInfo(String className, String info, int priority) {
            this.className = className;
            this.info = info;
            this.priority = priority;
        }

        public String getClassName() {
            return className;
        }

        public String getInfo() {
            return info;
        }

        public int getPriority() {
            return priority;
        }
    }
}
