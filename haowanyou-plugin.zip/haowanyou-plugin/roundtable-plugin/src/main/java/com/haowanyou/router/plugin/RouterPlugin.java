package com.haowanyou.router.plugin;

import com.android.build.gradle.AppExtension;
import com.android.build.gradle.BaseExtension;
import com.android.build.gradle.api.ApplicationVariant;
import com.haowanyou.router.plugin.task.RouterCleanTask;

import org.gradle.api.DomainObjectSet;
import org.gradle.api.Plugin;
import org.gradle.api.Project;
import org.gradle.api.Task;

import java.io.File;

/**
 * @author sunhaoyang
 */
public class RouterPlugin implements Plugin<Project> {

    Project project;

    @Override
    public void apply(Project project) {
        this.project = project;
        final RouterTransform transform = new RouterTransform();
        project.getExtensions().findByType(BaseExtension.class)
                .registerTransform(transform);
        project.afterEvaluate(afterProject -> {
            //每次代码注入前，先进行清理缓存
            checkCleanTask();
            DomainObjectSet<ApplicationVariant> variants =
                    afterProject.getExtensions().findByType(AppExtension.class).getApplicationVariants();
            for (ApplicationVariant variant : variants) {
                String variantName = capitalize(variant.getName());
                Task mergeJavaResTask = afterProject.getTasks().findByName(
                        "transformResourcesWithMergeJavaResFor" + variantName);
                mergeJavaResTask.doLast(task -> {
                    RouterHandler handler = new RouterHandler();
                    handler.scanServiceFiles(afterProject, mergeJavaResTask.getOutputs());
                    transform.setHandler(handler);
                });
            }
        });
    }

    private String capitalize(CharSequence str) {
        return (str == null || str.length() == 0) ? "" : "" + Character.toUpperCase(str.charAt(0))
                + str.subSequence(1, str.length());
    }

    /**
     * add customer clean task if not added
     *
     * @return task
     */
    void checkCleanTask() {
        File output = new File(project.getBuildDir(), "intermediates");
        RouterCleanTask cleanArchivesTask = project.getTasks().create("myCleanTask", RouterCleanTask.class, task -> task.setTarget(output));
        debug("checkCleanTask() create clean task, path:${output}");
        Task preBuild = project.getTasks().findByName("preBuild");
        preBuild.dependsOn(cleanArchivesTask);
    }

    /**
     * print debug messages
     *
     * @param msg  msg
     * @param vars vars
     */
    void debug(String msg, Object... vars) {
        project.getLogger().debug(msg, vars);
    }
}
