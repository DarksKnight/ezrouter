package com.haowanyou.router.plugin;

import com.android.SdkConstants;
import com.android.build.api.transform.Format;
import com.android.build.api.transform.QualifiedContent;
import com.android.build.api.transform.TransformInput;
import com.android.build.api.transform.TransformInvocation;
import com.android.build.gradle.internal.pipeline.TransformManager;
import com.google.common.base.Splitter;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Maps;
import com.haowanyou.router.plugin.visitor.component.InitMethodVisitor;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.gradle.api.Project;
import org.gradle.api.file.FileCollection;
import org.gradle.api.file.FileTree;
import org.gradle.api.tasks.TaskOutputs;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import static org.objectweb.asm.Opcodes.ASM5;

/**
 * class处理类
 *
 * @author sunhaoyang
 */
public class RouterHandler {

    private final String SERVICE_LOADER = "com/haowanyou/router/service/ServiceLoader.class";
    private File ServiceLoaderFile;
    private Map<String, List<String>> mapComponent = Maps.newHashMap();
    private Map<String, List<String>> mapActivity = Maps.newHashMap();

    /**
     * 执行操作
     *
     * @param invocation
     * @throws IOException
     */
    public void process(TransformInvocation invocation) throws IOException {
        initFiles(invocation);

        File optJar = new File(ServiceLoaderFile.getParent(), ServiceLoaderFile.getName() + ".opt");
        if (optJar.exists()) {
            optJar.delete();
        }
        JarFile testJarFile = new JarFile(ServiceLoaderFile);
        Enumeration enumeration = testJarFile.entries();
        JarOutputStream jarOutputStream = new JarOutputStream(new FileOutputStream(optJar));
        while (enumeration.hasMoreElements()) {
            JarEntry jarEntry = (JarEntry) enumeration.nextElement();
            String entryName = jarEntry.getName();
            ZipEntry zipEntry = new ZipEntry(entryName);
            InputStream inputStream = testJarFile.getInputStream(jarEntry);
            jarOutputStream.putNextEntry(zipEntry);
            if (entryName.equals(SERVICE_LOADER)) {
                ClassReader cr = new ClassReader(inputStream);
                ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
                ClassVisitor cv = new ClassVisitor(ASM5, cw) {
                    @Override
                    public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                        MethodVisitor mv = super.visitMethod(access, name, desc, signature, exceptions);
                        switch (name) {
                            case "init":
                                return new InitMethodVisitor(api, mv, mapComponent, mapActivity);
                            default:
                                return mv;
                        }
                    }
                };
                cr.accept(cv, ClassReader.EXPAND_FRAMES);
                File directory = invocation.getOutputProvider().getContentLocation(
                        "Router", TransformManager.CONTENT_CLASS,
                        ImmutableSet.of(QualifiedContent.Scope.PROJECT), Format.DIRECTORY);
                File dest = new File(directory, SERVICE_LOADER);
                dest.getParentFile().mkdirs();
                jarOutputStream.write(cw.toByteArray());
            } else {
                jarOutputStream.write(IOUtils.toByteArray(inputStream));
            }
            inputStream.close();
            jarOutputStream.closeEntry();
        }
        jarOutputStream.close();
        testJarFile.close();
        if (ServiceLoaderFile.exists()) {
            ServiceLoaderFile.delete();
        }
        optJar.renameTo(ServiceLoaderFile);
    }

    /**
     * 处理jar
     *
     * @param invocation
     */
    private void initFiles(TransformInvocation invocation) {
        for (TransformInput input : invocation.getInputs()) {
            input.getJarInputs().parallelStream().forEach(jarInput -> {
                File destFile = invocation.getOutputProvider().getContentLocation(jarInput.getName() + "_" + DigestUtils.md5Hex(jarInput.getFile().getAbsolutePath()), jarInput.getContentTypes(), jarInput.getScopes(), Format.JAR);
                try {
                    if (RouterUtils.shouldProcessPreDexJar(jarInput.getFile().getAbsolutePath())) {
                        JarFile jarFile = new JarFile(jarInput.getFile());
                        Enumeration enumeration = jarFile.entries();
                        while (enumeration.hasMoreElements()) {
                            JarEntry jarEntry = (JarEntry) enumeration.nextElement();
                            String entryName = jarEntry.getName();
                            if (entryName.equals(SERVICE_LOADER)) {
                                ServiceLoaderFile = destFile;
                                break;
                            }
                        }
                    }
                    FileUtils.copyFile(jarInput.getFile(), destFile);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
            input.getDirectoryInputs().parallelStream().forEach(directoryInput -> {
                File dest = invocation.getOutputProvider().getContentLocation(
                        directoryInput.getName(), directoryInput.getContentTypes(),
                        directoryInput.getScopes(), Format.DIRECTORY);
                try {
                    FileUtils.copyDirectory(directoryInput.getFile(), dest);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        }
    }

    /**
     * 扫描并解析在META-INF/services/haowanyou-router文件夹中的文件内容
     *
     * @param project
     * @param outputs
     */
    public void scanServiceFiles(Project project, TaskOutputs outputs) {
        FileCollection files = outputs.getFiles();
        for (File file : files) {
            FileTree tree = project.fileTree(file.getAbsolutePath());
            FileCollection filter = tree.filter(fileFilter -> fileFilter.getName().endsWith(SdkConstants.DOT_JAR));
            for (File jarFile : filter) {
                try (ZipFile zipFile = new ZipFile(jarFile)) {
                    if (RouterUtils.hasServiceEntry(zipFile)) {
                        File tempFile = new File(jarFile.getPath() + ".tmp");
                        try (ZipInputStream is = new ZipInputStream(new FileInputStream(jarFile));
                             ZipOutputStream os = new ZipOutputStream(new FileOutputStream(tempFile))) {
                            ZipEntry entry;
                            while ((entry = is.getNextEntry()) != null) {
                                if (RouterUtils.isServiceEntry(entry)) {
                                    String className = entry.getName().substring(entry.getName().lastIndexOf("/") + 1, entry.getName().length());
                                    BufferedReader reader = new BufferedReader(
                                            new InputStreamReader(is));
                                    System.out.println("name : " + className);
                                    String path = Splitter.on("_").splitToList(entry.getName()).get(0);
                                    switch (path.substring(path.lastIndexOf("/") + 1, path.length())) {
                                        case "component":
                                            processComponentFileContent(className, reader);
                                            break;
                                        case "page":
                                            processActivityFileContent(className, reader);
                                            break;
                                    }
                                } else {
                                    os.putNextEntry(new ZipEntry(entry));
                                    IOUtils.copy(is, os);
                                }
                            }
                            jarFile.delete();
                            tempFile.renameTo(jarFile);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 处理组件
     *
     * @param className
     * @param reader
     */
    private void processComponentFileContent(String className, BufferedReader reader) {
        mapComponent.put(className, RouterUtils.readLines(reader));
    }

    /**
     * 处理activity
     *
     * @param className
     * @param reader
     */
    private void processActivityFileContent(String className, BufferedReader reader) {
        mapActivity.put(className, RouterUtils.readLines(reader));
    }
}
