package com.haowanyou.router.plugin;

import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * 工具类
 * @author sunhaoyang
 */
public class RouterUtils {

    private final static String SERVICE_PATH = "META-INF/services/haowanyou-router/";

    public static boolean hasServiceEntry(ZipFile zipFile) {
        Enumeration<? extends ZipEntry> entries = zipFile.entries();
        while (entries.hasMoreElements()) {
            ZipEntry entry = entries.nextElement();
            if (isServiceEntry(entry)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isServiceEntry(ZipEntry entry) {
        return !entry.isDirectory() && entry.getName().startsWith(SERVICE_PATH);
    }

    public static boolean shouldProcessPreDexJar(String path) {
        return !path.contains("com.android.support") && !path.contains("/android/m2repository");
    }

    /**
     * 逐行读取文件
     * @param reader
     * @return
     */
    public static List<String> readLines(BufferedReader reader) {
        try {
            List<String> listContent = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                listContent.add(line);
            }
            return listContent;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Lists.newArrayList();
    }
}
