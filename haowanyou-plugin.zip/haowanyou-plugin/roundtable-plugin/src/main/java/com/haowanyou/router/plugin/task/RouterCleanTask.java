package com.haowanyou.router.plugin.task;

import org.gradle.api.DefaultTask;
import org.gradle.api.tasks.TaskAction;

import java.io.File;

/**
 * 清理缓存task
 *
 * @author: zhubinhua
 * @Date: 2018/10/24
 */
public class RouterCleanTask extends DefaultTask {

    private File target;

    public void setTarget(File target) {
        this.target = target;
    }

    public RouterCleanTask() {
        setDescription("clean all files in target dir");
    }

    @TaskAction
    public void showMessage() {
        getProject().getLogger().info("${name}: ${description}");
    }

    @TaskAction
    public void deleteAll() {
        getProject().getLogger().info("${name}: delete all files in ${target.absolutePath}");
        deleteDir(target);
    }

    private void deleteDir(File dir) {
        if (dir != null && dir.listFiles() != null) {
            for (File file : dir.listFiles()) {
                if (file.isFile()) {
                    file.delete();
                } else {
                    deleteDir(file);
                }
            }
        }
    }
}
