package sdk.proxy.android_xfz_jp;

import sdk.roundtable.base.RTPlugin;


public class BJMProxyXFZJPMediator extends RTPlugin {

}
