package com.haowanyou.router.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 事件注解
 * 标识哪些方法为自定义事件
 *
 * @author sunhaoyang
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.METHOD)
public @interface Event {

    String[] name() default "";

    int priority() default 0;

    boolean mainThread() default false;
}
