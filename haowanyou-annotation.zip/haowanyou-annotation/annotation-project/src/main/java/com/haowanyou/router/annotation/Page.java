package com.haowanyou.router.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * activity注解
 * 标识activity使用，用于跳转
 *
 * @author sunhaoyang
 */
@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.TYPE)
public @interface Page {

    String uri() default "";
}
