#!/bin/bash
set -ex
branch=$CI_BUILD_REF_NAME
release=`echo $branch | awk -F '-' '{print $1}'`
if [ "$release" != "release" ]; then
	exit 1;
fi
version=`echo $branch | awk -F '-' '{print $2}'`
./gradlew uploadArchives -PVERSION_NAME=$version